﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using GART.Data;
using GART.BaseControls;
using System.Device.Location;
using System.Collections.ObjectModel;

namespace a
{
    public partial class WestAugMap : PhoneApplicationPage
    {
        private readonly GeoCoordinateWatcher _GeoWatcher = new GeoCoordinateWatcher(GeoPositionAccuracy.High);
        private ObservableCollection<ARItem> locations;
        private GeoPosition<GeoCoordinate> CurrentPosition { get; set; }

        public WestAugMap()
        {
            InitializeComponent();
            _GeoWatcher.PositionChanged += (o, args) => Dispatcher.BeginInvoke(() =>
            {
                CurrentPosition = _GeoWatcher.Position;

                locations = new ObservableCollection<ARItem>
                {
                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.848902,89.366716), 
                        Content = "Bogra",
                        Description = GetLocationText(24.848902,89.366716)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.640121,88.856431), 
                        Content = "Chuadanga",
                        Description = GetLocationText(23.640121,88.856431)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(25.62516,88.632778), 
                        Content = "Dinajpur",
                        Description = GetLocationText(25.62516,88.632778)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(25.333185,89.542068), 
                        Content = "Gaibandha",
                        Description = GetLocationText(25.333185,89.542068)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.130305,89.062854), 
                        Content = "Isshordi",
                        Description = GetLocationText(24.130305,89.062854)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.154408,89.208616), 
                        Content = "Jessore",
                        Description = GetLocationText(23.154408,89.208616)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(25.099493,89.025818), 
                        Content = "Joypurhat",
                        Description = GetLocationText(25.099493,89.025818)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(22.822311,89.557965), 
                        Content = "Khulna",
                        Description = GetLocationText(22.822311,89.557965)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.411417,88.966316), 
                        Content = "Natore",
                        Description = GetLocationText(24.411417,88.966316)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.865353,89.032835), 
                        Content = "Paradha",
                        Description = GetLocationText(23.865353,89.032835)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(25.654119,88.915483), 
                        Content = "Parbatipur",
                        Description = GetLocationText(25.654119,88.915483)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.375635,88.610054), 
                        Content = "Rajshahi",
                        Description = GetLocationText(24.375635,88.610054)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(25.728603,89.263655), 
                        Content = "Rangpur",
                        Description = GetLocationText(25.728603,89.263655)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.806253,88.985928), 
                        Content = "Santahar",
                        Description = GetLocationText(24.806253,88.985928)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.44879,89.705426), 
                        Content = "Sirajganj",
                        Description = GetLocationText(24.44879,89.705426)
                    },

                    /*
                     * Geo-Cordinate Paoa jay nai
                     * 
                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(), 
                        Content = "Ullapara",
                        Description = GetLocationText()
                    }
            
                    */
                };

                ardisplay.ARItems = locations;
            });

            _GeoWatcher.Start();

        }

        private string GetLocationText(double lat, double lon)
        {
            if (CurrentPosition != null && CurrentPosition.Location != null)
            {
                var start = new GeoCoordinate(CurrentPosition.Location.Latitude, CurrentPosition.Location.Longitude);
                var end = new GeoCoordinate(lat, lon);
                var distance = start.GetDistanceTo(end);

                return distance < 1000
                    ? string.Format("{0}m away.", Math.Round((double)distance, 0))
                    : string.Format("{0}km away.", Math.Round((double)distance / 1000, 2));
            }

            return string.Empty;
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            // Stop AR services
            ardisplay.StopServices();

            base.OnNavigatedFrom(e);
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            // Start AR services
            ardisplay.StartServices();

            base.OnNavigatedTo(e);
        }

        protected override void OnOrientationChanged(OrientationChangedEventArgs e)
        {
            base.OnOrientationChanged(e);

            if (ardisplay != null)
            {
                var orientation = ControlOrientation.Default;

                switch (e.Orientation)
                {
                    case PageOrientation.LandscapeLeft:
                        orientation = ControlOrientation.Clockwise270Degrees;
                        ardisplay.Visibility = Visibility.Visible;
                        break;
                    case PageOrientation.LandscapeRight:
                        orientation = ControlOrientation.Clockwise90Degrees;
                        ardisplay.Visibility = Visibility.Visible;
                        break;

                }

                ardisplay.Orientation = orientation;
            }
        }

    }
}