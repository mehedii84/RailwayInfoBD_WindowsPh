﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace a
{
    public partial class mapscc : PhoneApplicationPage
    {
        string ShowClick;
        public mapscc()
        {
            InitializeComponent();
        }
        private void TrainSchedule_Clicked(object sender, RoutedEventArgs e)
        {

            if (TrainSchedule1.IsPressed == true)
            {
                ShowClick = "0";
            }

            if (TrainSchedule2.IsPressed == true)
            {
                ShowClick = "1";
            }

            if (TrainSchedule3.IsPressed == true)
            {
                ShowClick = "2";
            }

            if (TrainSchedule4.IsPressed == true)
            {
                ShowClick = "3";
            }

            if (TrainSchedule5.IsPressed == true)
            {
                ShowClick = "4";
            }

            if (TrainSchedule6.IsPressed == true)
            {
                ShowClick = "5";
            }

            if (TrainSchedule7.IsPressed == true)
            {
                ShowClick = "6";
            }

            if (TrainSchedule8.IsPressed == true)
            {
                ShowClick = "7";
            }

            if (TrainSchedule9.IsPressed == true)
            {
                ShowClick = "8";
            }

            if (TrainSchedule10.IsPressed == true)
            {
                ShowClick = "9";
            }

            if (TrainSchedule11.IsPressed == true)
            {
                ShowClick = "10";
            }

            if (TrainSchedule12.IsPressed == true)
            {
                ShowClick = "11";
            }

            if (TrainSchedule13.IsPressed == true)
            {
                ShowClick = "12";
            }

            if (TrainSchedule14.IsPressed == true)
            {
                ShowClick = "13";
            }

            if (TrainSchedule15.IsPressed == true)
            {
                ShowClick = "14";
            }

            if (TrainSchedule16.IsPressed == true)
            {
                ShowClick = "15";
            }

            NavigationService.Navigate(new Uri("/westmapschedule.xaml?msg=" + ShowClick, UriKind.Relative));

        }
    }
}