﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using GART.Data;
using GART.BaseControls;
using System.Device.Location;
using System.Collections.ObjectModel;

namespace a
{
    public partial class EastAugMap : PhoneApplicationPage
    {
        private readonly GeoCoordinateWatcher _GeoWatcher = new GeoCoordinateWatcher(GeoPositionAccuracy.High);
        private ObservableCollection<ARItem> locations;
        private GeoPosition<GeoCoordinate> CurrentPosition { get; set; }

        public EastAugMap()
        {
            InitializeComponent();
                    _GeoWatcher.PositionChanged += (o, args) => Dispatcher.BeginInvoke(() =>
            {
                CurrentPosition = _GeoWatcher.Position;

                locations = new ObservableCollection<ARItem>
                {
                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.869513,91.205875), 
                        Content = "Akhaura",
                        Description = GetLocationText(23.869513,91.205875)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.008835,90.793533), 
                        Content = "Bhairab Bazar",
                        Description = GetLocationText(24.008835,90.793533)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.966843,91.108478), 
                        Content = "Brahman Baria",
                        Description = GetLocationText(23.966843,91.108478)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.855698,90.411615), 
                        Content = "Biman Bandar",
                        Description = GetLocationText(23.855698,90.411615)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.230344,90.644006), 
                        Content = "Chandpur",
                        Description = GetLocationText(23.230344,90.644006)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(22.334635,91.830164), 
                        Content = "Chittagong",
                        Description = GetLocationText(22.334635,91.830164)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.464093,91.166779), 
                        Content = "Comilla",
                        Description = GetLocationText(23.464093,91.166779)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.732496,90.425931), 
                        Content = "Dhaka",
                        Description = GetLocationText(23.732496,90.425931)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.013843,91.403457), 
                        Content = "Feni",
                        Description = GetLocationText(23.013843,91.403457)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.453654,90.547811), 
                        Content = "Goforgaon",
                        Description = GetLocationText(24.453654,90.547811)
                    },

                    /*
                     * I don't know whether it is in Bangladesh or not

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(), 
                        Content = "Jagannath",
                        Description = GetLocationText()
                    },

                    */

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.915281,89.954528), 
                        Content = "Jamalpur",
                        Description = GetLocationText(24.915281,89.954528)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.426735,90.788437), 
                        Content = "Kishoreganj",
                        Description = GetLocationText(24.426735,90.788437)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.522879,92.036587), 
                        Content = "Kulaura",
                        Description = GetLocationText(24.522879,92.036587)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.254674,91.126428), 
                        Content = "Laksham",
                        Description = GetLocationText(23.254674,91.126428)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.754275,90.409538), 
                        Content = "Mymensingh",
                        Description = GetLocationText(24.754275,90.409538)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(22.827967,91.101376), 
                        Content = "Noakhali",
                        Description = GetLocationText(22.827967,91.101376)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(23.931289,90.721296), 
                        Content = "Narshingdi",
                        Description = GetLocationText(23.931289,90.721296)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.278656,91.449891), 
                        Content = "Shaestaganj",
                        Description = GetLocationText(24.278656,91.449891)
                    },
 
                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.7608,89.8401), 
                        Content = "Sarishabari",
                        Description = GetLocationText(24.7608,89.8401)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.306858,91.734849), 
                        Content = "Sreemongol",
                        Description = GetLocationText(24.306858,91.734849)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.882251,91.868187), 
                        Content = "Sylhet",
                        Description = GetLocationText(24.882251,91.868187)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.274098,89.937383), 
                        Content = "Tangail",
                        Description = GetLocationText(24.274098,89.937383)
                    },

                    new Destination()
                    {
                        GeoLocation = new GeoCoordinate(24.274391,89.937426), 
                        Content = "Tarakandi",
                        Description = GetLocationText(24.274391,89.937426)
                    }

            
                };

                ardisplay.ARItems = locations;
            });

            _GeoWatcher.Start();

        }

        private string GetLocationText(double lat, double lon)
        {
            if (CurrentPosition != null && CurrentPosition.Location != null)
            {
                var start = new GeoCoordinate(CurrentPosition.Location.Latitude, CurrentPosition.Location.Longitude);
                var end = new GeoCoordinate(lat, lon);
                var distance = start.GetDistanceTo(end);

                return distance < 1000
                    ? string.Format("{0}m away.", Math.Round((double)distance, 0))
                    : string.Format("{0}km away.", Math.Round((double)distance / 1000, 2));
            }

            return string.Empty;
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            // Stop AR services
            ardisplay.StopServices();

            base.OnNavigatedFrom(e);
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            // Start AR services
            ardisplay.StartServices();

            base.OnNavigatedTo(e);
        }

        protected override void OnOrientationChanged(OrientationChangedEventArgs e)
        {
            base.OnOrientationChanged(e);

            if (ardisplay != null)
            {
                var orientation = ControlOrientation.Default;

                switch (e.Orientation)
                {
                    case PageOrientation.LandscapeLeft:
                        orientation = ControlOrientation.Clockwise270Degrees;
                        ardisplay.Visibility = Visibility.Visible;
                        break;
                    case PageOrientation.LandscapeRight:
                        orientation = ControlOrientation.Clockwise90Degrees;
                        ardisplay.Visibility = Visibility.Visible;
                        break;

                }

                ardisplay.Orientation = orientation;
            }
        }

    }
}