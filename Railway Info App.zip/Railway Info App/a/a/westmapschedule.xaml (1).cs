﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.Xml.Linq;

namespace a
{
    public partial class westmapschedule : PhoneApplicationPage
    {
        int NowDoingWork;
        public westmapschedule()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            string msg = "";

            if (NavigationContext.QueryString.TryGetValue("msg", out msg))
            {
                NowDoingWork = Int32.Parse(msg);
            }
        }

        private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
        {
            if (NowDoingWork == 0)
            {
                Header.Text = "Bogra";

                var doc1 = XDocument.Load(@"westscheduler_bogra.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 1)
            {
                Header.Text = "Chuadanga";

                var doc1 = XDocument.Load(@"westscheduler_chuadanga.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();
                    
                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 2)
            {
                Header.Text = "Dinajpur";

                var doc1 = XDocument.Load(@"westscheduler_dinajpur.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 3)
            {
                Header.Text = "gaibandha";

                var doc1 = XDocument.Load(@"westscheduler_gaibandha.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 4)
            {
                Header.Text = "Isshordi";

                var doc1 = XDocument.Load(@"westscheduler_isshordi.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 5)
            {
                Header.Text = "Jessore";

                var doc1 = XDocument.Load(@"westscheduler_jessore.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 6)
            {
                Header.Text = "Joypurhat";

                var doc1 = XDocument.Load(@"westscheduler_joypurhat.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 7)
            {
                Header.Text = "khulna";

                var doc1 = XDocument.Load(@"westscheduler_khulna.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 8)
            {
                Header.Text = "Natore";

                var doc1 = XDocument.Load(@"westscheduler_natore.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 9)
            {
                Header.Text = "Paradha";

                var doc1 = XDocument.Load(@"westscheduler_paradha.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 10)
            {
                Header.Text = "Parbatipur";

                var doc1 = XDocument.Load(@"westscheduler_parbatipur.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 11)
            {
                Header.Text = "Rajshahi";

                var doc1 = XDocument.Load(@"westscheduler_rajshahi.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 12)
            {
                Header.Text = "Rangpur";

                var doc1 = XDocument.Load(@"westscheduler_rangpur.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 13)
            {
                Header.Text = "Santahar";

                var doc1 = XDocument.Load(@"westscheduler_santahar.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 14)
            {
                Header.Text = "Sirajganj";

                var doc1 = XDocument.Load(@"westscheduler_sirajganj.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }
            }


            if (NowDoingWork == 15)
            {
                Header.Text = "Ullapara";

                var doc1 = XDocument.Load(@"westscheduler_ullapara.xml");


                List<XElement> elements = doc1.Descendants("item").ToList();

                // Now we're putting the informations that we got in our ListBox in the XAML code
                // we have to use a foreach statment to be able to read all the elements 
                // Description 1 , Link1 , Title1 are the attributes in the RSSItem class that I've already added
                List<RSSItem> aux = new List<RSSItem>();
                foreach (XElement rssItem in elements)
                {
                    RSSItem rss = new RSSItem();

                    rss.TrainNo = rssItem.Element("trainno").Value;
                    rss.Name = rssItem.Element("name").Value;
                    rss.OffDay = rssItem.Element("offday").Value;
                    rss.From = rssItem.Element("from").Value;
                    rss.Departure = rssItem.Element("departure").Value;
                    rss.To = rssItem.Element("to").Value;
                    rss.Arrival = rssItem.Element("arrival").Value;

                    aux.Add(rss);

                    TextBlock tbTrainNo = new TextBlock();
                    tbTrainNo.Text = "Train no : " + rss.TrainNo;
                    ListBoxRss.Items.Add(tbTrainNo);


                    TextBlock tbName = new TextBlock();
                    tbName.Text = "Train name : " + rss.Name;
                    ListBoxRss.Items.Add(tbName);


                    TextBlock tbOffDay = new TextBlock();
                    tbOffDay.Text = "Off day : " + rss.OffDay;
                    ListBoxRss.Items.Add(tbOffDay);


                    TextBlock tbFrom = new TextBlock();
                    tbFrom.Text = "From : " + rss.From;
                    ListBoxRss.Items.Add(tbFrom);


                    TextBlock tbDeparture = new TextBlock();
                    tbDeparture.Text = "Departure : " + rss.Departure;
                    ListBoxRss.Items.Add(tbDeparture);


                    TextBlock tbTo = new TextBlock();
                    tbTo.Text = "To : " + rss.To;
                    ListBoxRss.Items.Add(tbTo);


                    TextBlock tbArrival = new TextBlock();
                    tbArrival.Text = "Arrival :  " + rss.Arrival + "\n\n" + "------------------------------------------------------------------------------------------------------" + "\n";
                    ListBoxRss.Items.Add(tbArrival);

                }




            }

        }
    }
}
       

