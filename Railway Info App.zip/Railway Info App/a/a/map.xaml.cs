﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace a
{
    public partial class map : PhoneApplicationPage
    {
        string x;
        public map()
        {
            InitializeComponent();
        }

        private void eastaugmap_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/EastAugMap.xaml", UriKind.Relative));
        }

        private void westaugmap_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/WestAugMap.xaml", UriKind.Relative));
        }

        private void eastbingmap_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/BingMapEast.xaml", UriKind.Relative));
        }

        private void westbingmap_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/BingMapWest.xaml", UriKind.Relative));
        }
    }
}