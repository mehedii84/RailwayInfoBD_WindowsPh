﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using a.Resources;

namespace a
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private void briefinfo_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/BRIEF.xaml", UriKind.Relative));
        }

        private void trainschedules_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/train.xaml", UriKind.Relative));
        }

        private void map_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/map.xaml", UriKind.Relative));
        }

        private void online_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/online.xaml", UriKind.Relative));
        }

       
    }
}