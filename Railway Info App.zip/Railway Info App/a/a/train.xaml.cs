﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace a
{
    public partial class train : PhoneApplicationPage
    {
        string x;
        public train()
        {
            InitializeComponent();
        }

        private void eastzone_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/easttrainscc.xaml",UriKind.Relative));          
        }

        private void westzone_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/mapscc.xaml", UriKind.Relative));
        }


    }
}