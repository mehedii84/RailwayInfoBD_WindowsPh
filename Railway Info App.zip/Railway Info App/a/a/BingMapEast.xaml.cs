﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.Device.Location;
using Microsoft.Phone.Maps.Controls;
using Microsoft.Phone.Maps.Services;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Input;

namespace a
{
    public partial class BingMapEast : PhoneApplicationPage
    {
        private GeoCoordinate MyCoordinate = null;
        private ReverseGeocodeQuery MyReverseGeocodeQuery = null;


        public BingMapEast()
        {
            InitializeComponent();
        }

        private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
        {
            map1.Layers.Clear();
            MapLayer mapLayer = new MapLayer();

            // Draw marker for current position
            if (MyCoordinate != null)
            {
                DrawMapMarker(MyCoordinate, Colors.Red, mapLayer);
            }


            map1.Layers.Add(mapLayer);

        }


        private void DrawMapMarker(GeoCoordinate coordinate, Color color, MapLayer mapLayer)
        {
            Polygon polygon = new Polygon();


            polygon.Points.Add(new Point(23.869513, 91.205875));
            polygon.Points.Add(new Point(24.008835, 90.793533));
            polygon.Points.Add(new Point(23.966843, 91.108478));
            polygon.Points.Add(new Point(23.855698, 90.411615));
            polygon.Points.Add(new Point(23.230344, 90.644006));
            polygon.Points.Add(new Point(22.334635, 91.830164));
            polygon.Points.Add(new Point(23.464093, 91.166779));
            polygon.Points.Add(new Point(23.732496, 90.425931));
            polygon.Points.Add(new Point(23.013843, 91.403457));
            polygon.Points.Add(new Point(24.453654, 90.547811));
            polygon.Points.Add(new Point(24.915281, 89.954528));
            polygon.Points.Add(new Point(24.426735, 90.788437));
            polygon.Points.Add(new Point(24.522879, 92.036587));
            polygon.Points.Add(new Point(23.254674, 91.126428));
            polygon.Points.Add(new Point(24.754275, 90.409538));
            polygon.Points.Add(new Point(22.827967, 91.101376));
            polygon.Points.Add(new Point(23.931289, 90.721296));
            polygon.Points.Add(new Point(24.278656, 91.449891));
            polygon.Points.Add(new Point(24.306858, 91.734849));
            polygon.Points.Add(new Point(24.882251, 91.868187));
            polygon.Points.Add(new Point(24.274098, 89.937383));
            polygon.Points.Add(new Point(24.274391, 89.937426));
                        
            
            polygon.Fill = new SolidColorBrush(color);

            polygon.Tag = new GeoCoordinate(coordinate.Latitude, coordinate.Longitude);
            polygon.MouseLeftButtonUp += new MouseButtonEventHandler(Marker_Click);

            MapOverlay overlay = new MapOverlay();
            overlay.Content = polygon;
            overlay.GeoCoordinate = new GeoCoordinate(coordinate.Latitude, coordinate.Longitude);
            overlay.PositionOrigin = new Point(0.0, 1.0);
            mapLayer.Add(overlay);
        }


        private void Marker_Click(object sender, EventArgs e)
        {
            Polygon p = (Polygon)sender;
            GeoCoordinate geoCoordinate = (GeoCoordinate)p.Tag;
            MyReverseGeocodeQuery = new ReverseGeocodeQuery();
            MyReverseGeocodeQuery.GeoCoordinate = new GeoCoordinate(geoCoordinate.Latitude, geoCoordinate.Longitude);
            MyReverseGeocodeQuery.QueryCompleted += ReverseGeocodeQuery_QueryCompleted;
            MyReverseGeocodeQuery.QueryAsync();
        }

        private void ReverseGeocodeQuery_QueryCompleted(object sender, QueryCompletedEventArgs<IList<MapLocation>> e)
        {
            if (e.Error == null)
            {
                if (e.Result.Count > 0)
                {
                    MapAddress address = e.Result[0].Information.Address;
                    String msgBoxText = "";


                    if (address.Country.Length > 0) msgBoxText += "\n" + address.Country;
                    MessageBox.Show(msgBoxText, "Map Explorer", MessageBoxButton.OK);
                }

            }
        }


    }
}