﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace a
{
    public partial class BRIEF : PhoneApplicationPage
    {
        string x;
        public BRIEF()
        {
            InitializeComponent();
            Storyboard1.Begin();
        }

        private void history_Click(object sender, RoutedEventArgs e)
        {
            if (history.IsPressed==true)
            {

                x = "0";
            }

            if (ticket.IsPressed == true)
            {

                x = "1";
            }

            if (acc.IsPressed == true)
            {

                x = "2";
            }

            if (cargo.IsPressed == true)
            {

                x = "3";
            }


            NavigationService.Navigate(new Uri("/briefmodels.xaml?msg=" + x, UriKind.Relative));
        }
    }
}