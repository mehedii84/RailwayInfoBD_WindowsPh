﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.Device.Location;
using Microsoft.Phone.Maps.Controls;
using Microsoft.Phone.Maps.Services;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Input;

namespace a
{
    public partial class BingMapWest : PhoneApplicationPage
    {
        private GeoCoordinate MyCoordinate = null;
        private ReverseGeocodeQuery MyReverseGeocodeQuery = null;


        public BingMapWest()
        {
            InitializeComponent();
        }

        private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
        {
            map1.Layers.Clear();
            MapLayer mapLayer = new MapLayer();

            // Draw marker for current position
            if (MyCoordinate != null)
            {
                DrawMapMarker(MyCoordinate, Colors.Red, mapLayer);
            }


            map1.Layers.Add(mapLayer);

        }


        private void DrawMapMarker(GeoCoordinate coordinate, Color color, MapLayer mapLayer)
        {
            Polygon polygon = new Polygon();


            polygon.Points.Add(new Point(24.848902, 89.366716));
            polygon.Points.Add(new Point(23.640121, 88.856431));
            polygon.Points.Add(new Point(25.62516, 88.632778));
            polygon.Points.Add(new Point(25.333185, 89.542068));
            polygon.Points.Add(new Point(24.130305, 89.062854));
            polygon.Points.Add(new Point(23.154408, 89.208616));
            polygon.Points.Add(new Point(25.099493, 89.025818));
            polygon.Points.Add(new Point(22.822311, 89.557965));
            polygon.Points.Add(new Point(24.411417, 88.966316));
            polygon.Points.Add(new Point(23.865353, 89.032835));
            polygon.Points.Add(new Point(25.654119, 88.915483));
            polygon.Points.Add(new Point(24.375635, 88.610054));
            polygon.Points.Add(new Point(25.728603, 89.263655));
            polygon.Points.Add(new Point(24.806253, 88.985928));
            polygon.Points.Add(new Point(24.44879, 89.705426));


            polygon.Fill = new SolidColorBrush(color);

            polygon.Tag = new GeoCoordinate(coordinate.Latitude, coordinate.Longitude);
            polygon.MouseLeftButtonUp += new MouseButtonEventHandler(Marker_Click);

            MapOverlay overlay = new MapOverlay();
            overlay.Content = polygon;
            overlay.GeoCoordinate = new GeoCoordinate(coordinate.Latitude, coordinate.Longitude);
            overlay.PositionOrigin = new Point(0.0, 1.0);
            mapLayer.Add(overlay);
        }


        private void Marker_Click(object sender, EventArgs e)
        {
            Polygon p = (Polygon)sender;
            GeoCoordinate geoCoordinate = (GeoCoordinate)p.Tag;
            MyReverseGeocodeQuery = new ReverseGeocodeQuery();
            MyReverseGeocodeQuery.GeoCoordinate = new GeoCoordinate(geoCoordinate.Latitude, geoCoordinate.Longitude);
            MyReverseGeocodeQuery.QueryCompleted += ReverseGeocodeQuery_QueryCompleted;
            MyReverseGeocodeQuery.QueryAsync();
        }

        private void ReverseGeocodeQuery_QueryCompleted(object sender, QueryCompletedEventArgs<IList<MapLocation>> e)
        {
            if (e.Error == null)
            {
                if (e.Result.Count > 0)
                {
                    MapAddress address = e.Result[0].Information.Address;
                    String msgBoxText = "";


                    if (address.Country.Length > 0) msgBoxText += "\n" + address.Country;
                    MessageBox.Show(msgBoxText, "Map Explorer", MessageBoxButton.OK);
                }

            }
        }


    }
}