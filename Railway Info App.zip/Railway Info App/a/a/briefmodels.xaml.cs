﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace a
{
    public partial class briefmodels : PhoneApplicationPage
    {

        int NowToShow;
        public briefmodels()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            string msg = "";
            if(NavigationContext.QueryString.TryGetValue("msg",out msg))
            {


                NowToShow = Int32.Parse(msg);
            }
        }

        private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
        {
            if (NowToShow == 0)
            {

                title.Text = "history";
                details.Text = "Railway operation in today's Bangladesh began on 15 November 1862 when 53.11 kilometres of 5 ft 6 in (1,676 mm) (broad gauge) line were opened for traffic between Dorshona of Chuadanga District and Jogotee of Kushtia District. The next 14.98 kilometres 1,000 mm (3 ft 3 3⁄8 in) (metre gauge) line was opened for traffic on 4 January 1885. In 1891, the construction of then Bengal Assam Railway was taken up by the British Government assistance but that was later on taken over by the Bengal Assam Railway Company. On 1 July 1895, two sections of metre gauge lines were opened between Chittagong and Comilla, a length of 149.89 kilometres and between Laksam Upazila and Chandpur District, a length of 50.89 kilometres. Railway Companies formed in England took up the construction and operation of these sections in middle and late 19th century.";
            }

            if (NowToShow == 1)
            {

                title.Text = "fares &amp; ticket";
                details.Text = "BR Fares are relatively cheaper than the bus fares. Ticketing services are available at all railway stations across Bangladesh. Most railway stations are computerised and connected to a central network. Printed tickets are provided to the passengers. Tickets can be bought 10 (ten) days before the journey. 100% (excluding clerical charge) refund is available if the ticket is returned 48 hours prior to departure.";

            }

            if (NowToShow == 2)
            
            {
                title.Text = "accomodation classes";
                details.Text = "1. First Class AC\n" + "2. First Class\n" + "3.  First Class Chair\n" + "4. 2nd Class-Shovon Chair\n" + "5. 2nd Class-Shovon\n" + "6. 2nd Class- Shulov";
            }

            if (NowToShow == 3)
            {
                title.Text = "cargo service";
                details.Text = "The railway has been facing tough competition with other modes of transport for the high rated traffic, which provide more revenue. As a national carrier, BR is obliged to carry essential commodities like food grains, fertiliser, jute, cement, coal, iron and steel, stone & boulders, petroleum products, salt, sugar etc. to the remote corners of the country at a cheap rates. Freight traffic during 2004–2005 was 3,206 thousand Metric Tons.";
            }

        }
    }
}

